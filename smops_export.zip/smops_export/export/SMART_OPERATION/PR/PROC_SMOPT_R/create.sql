CREATE PROCEDURE PROC_SMOPT_R(IN input_tbl SMOPT_R, OUT result CORRELATION) LANGUAGE RLANG AS
BEGIN
  repo_name <- unique(input_tbl$REPORT_NAME);
  temp_frame <- NULL;
  for (i in 1:length(repo_name)){
  temp_frame <- cbind(temp_frame, input_tbl$RESP_TOTAL[input_tbl$REPORT_NAME == repo_name[i]])
  };
  temp_frame <- as.data_frame(temp_frame);
  names(temp_frame) <- repo_name;
  result　<- as.data.frame(cor(temp_frame), row.names = F);
END;