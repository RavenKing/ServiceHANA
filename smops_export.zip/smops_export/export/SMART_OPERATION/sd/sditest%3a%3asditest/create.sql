CREATE TASK "SMART_OPERATION"."sditest::sditest" USING PLAN '<?xml version="1.0" encoding="UTF-8"?>
<taskDefinition defaultSchema="ZENGHENG" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="taskPlan.xsd" name="" version="" description="">
<inputSources>
<inputSource  type="rowTable" schema="SMART_OPERATION" name="SMCUST" binding="SMCUST">
<mapping source="CUSTOMER_ID" target="CUSTOMER_ID"/>
<mapping source="CUSTOMER_NAME" target="CUSTOMER_NAME"/>
<mapping source="INDUSTRY" target="INDUSTRY"/>
<mapping source="COUNTRY" target="COUNTRY"/>
<mapping source="CITY" target="CITY"/>
<mapping source="SYSTEMID" target="SYSTEMID"/>
<mapping source="CLIENT" target="CLIENT"/>
<mapping source="REGION" target="REGION"/>
</inputSource>
</inputSources>
<outputSources>
<outputSource  schema="SMART_OPERATION" name="TEMPLATERESULT" writerType="opcode" type="columnTable" binding="DATA_2">
<mapping source="CUSTOMER_ID" target="CUSTOMER_ID"/>
<mapping source="CUSTOMER_NAME" target="CUSTOMER_NAME"/>
<mapping source="INDUSTRY" target="INDUSTRY"/>
<mapping source="COUNTRY" target="COUNTRY"/>
<mapping source="CITY" target="CITY"/>
<mapping source="REGION" target="REGION"/>
</outputSource>
</outputSources>
<operationDefinition  name="">
<inputs>
<input name="SMCUST">
<attribute name="CUSTOMER_ID" datatype="int" ></attribute>
<attribute name="CUSTOMER_NAME" datatype="varchar" length="50" ></attribute>
<attribute name="INDUSTRY" datatype="varchar" length="20" ></attribute>
<attribute name="COUNTRY" datatype="varchar" length="10" ></attribute>
<attribute name="CITY" datatype="varchar" length="20" ></attribute>
<attribute name="SYSTEMID" datatype="varchar" length="3" ></attribute>
<attribute name="CLIENT" datatype="varchar" length="3" ></attribute>
<attribute name="REGION" datatype="varchar" length="10" ></attribute>
</input>
</inputs>
<variables>
</variables>
<operations>
<projection name="INPUT">
<inputs>
<input name="SMCUST">
</input>
</inputs>
<settings>
</settings>
<outputs>
<output>
<attribute name="CUSTOMER_ID" datatype="int" >"SMCUST"."CUSTOMER_ID"</attribute>
<attribute name="CUSTOMER_NAME" datatype="varchar" length="50" >"SMCUST"."CUSTOMER_NAME"</attribute>
<attribute name="INDUSTRY" datatype="varchar" length="20" >"SMCUST"."INDUSTRY"</attribute>
<attribute name="COUNTRY" datatype="varchar" length="10" >"SMCUST"."COUNTRY"</attribute>
<attribute name="CITY" datatype="varchar" length="20" >"SMCUST"."CITY"</attribute>
<attribute name="SYSTEMID" datatype="varchar" length="3" >"SMCUST"."SYSTEMID"</attribute>
<attribute name="CLIENT" datatype="varchar" length="3" >"SMCUST"."CLIENT"</attribute>
<attribute name="REGION" datatype="varchar" length="10" >"SMCUST"."REGION"</attribute>
</output>
</outputs>
</projection>
<projection name="FILTER">
<inputs>
<input name="INPUT">
</input>
</inputs>
<settings>
<filter>"INPUT"."COUNTRY" = ''China''</filter>
</settings>
<outputs>
<output>
<attribute name="CUSTOMER_ID" datatype="int" >"INPUT"."CUSTOMER_ID"</attribute>
<attribute name="CUSTOMER_NAME" datatype="varchar" length="50" >"INPUT"."CUSTOMER_NAME"</attribute>
<attribute name="INDUSTRY" datatype="varchar" length="20" >"INPUT"."INDUSTRY"</attribute>
<attribute name="COUNTRY" datatype="varchar" length="10" >"INPUT"."COUNTRY"</attribute>
<attribute name="CITY" datatype="varchar" length="20" >"INPUT"."CITY"</attribute>
<attribute name="REGION" datatype="varchar" length="10" >"INPUT"."REGION"</attribute>
</output>
</outputs>
</projection>
<projection name="SORT">
<inputs>
<input name="INPUT_2">
</input>
</inputs>
<settings>
<sorts>
<sort attribute="CUSTOMER_NAME" direction="asc"/>
</sorts>
</settings>
<outputs>
<output>
<attribute name="CUSTOMER_ID" datatype="int" ></attribute>
<attribute name="CUSTOMER_NAME" datatype="varchar" length="50" ></attribute>
<attribute name="INDUSTRY" datatype="varchar" length="20" ></attribute>
<attribute name="COUNTRY" datatype="varchar" length="10" ></attribute>
<attribute name="CITY" datatype="varchar" length="20" ></attribute>
<attribute name="REGION" datatype="varchar" length="10" ></attribute>
</output>
</outputs>
</projection>
<projection name="INPUT_2">
<inputs>
<input name="FILTER">
</input>
</inputs>
<settings>
</settings>
<outputs>
<output>
<attribute name="CUSTOMER_ID" datatype="int" >"FILTER"."CUSTOMER_ID"</attribute>
<attribute name="CUSTOMER_NAME" datatype="varchar" length="50" >"FILTER"."CUSTOMER_NAME"</attribute>
<attribute name="INDUSTRY" datatype="varchar" length="20" >"FILTER"."INDUSTRY"</attribute>
<attribute name="COUNTRY" datatype="varchar" length="10" >"FILTER"."COUNTRY"</attribute>
<attribute name="CITY" datatype="varchar" length="20" >"FILTER"."CITY"</attribute>
<attribute name="REGION" datatype="varchar" length="10" >"FILTER"."REGION"</attribute>
</output>
</outputs>
</projection>
<projection name="DATA_2">
<inputs>
<input name="SORT">
</input>
</inputs>
<settings>
</settings>
<outputs>
<output>
<attribute name="CUSTOMER_ID" datatype="int" >"SORT"."CUSTOMER_ID"</attribute>
<attribute name="CUSTOMER_NAME" datatype="varchar" length="50" >"SORT"."CUSTOMER_NAME"</attribute>
<attribute name="INDUSTRY" datatype="varchar" length="20" >"SORT"."INDUSTRY"</attribute>
<attribute name="COUNTRY" datatype="varchar" length="10" >"SORT"."COUNTRY"</attribute>
<attribute name="CITY" datatype="varchar" length="20" >"SORT"."CITY"</attribute>
<attribute name="REGION" datatype="varchar" length="10" >"SORT"."REGION"</attribute>
</output>
</outputs>
</projection>
</operations>
</operationDefinition>
</taskDefinition>'