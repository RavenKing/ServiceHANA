CREATE PROCEDURE MY_F(IN input1 PRIME, OUT result PRIME_SQR)
LANGUAGE RLANG AS
BEGIN
  result <- as.data.frame(input1$NUMBER^2);
  names(result) <- c("NUMBER");
END;